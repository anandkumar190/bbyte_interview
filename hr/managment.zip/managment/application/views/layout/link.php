
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/font-awesome.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/material-design-iconic-font.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/bootstrap.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/animate.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/layout.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/components.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/widgets.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/plugins.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/pages.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/bootstrap-extend.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/common.css">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/responsive.css">
	<link type="text/css" rel="stylesheet" href="http://code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">

	<style>
		.thumbnail{
			width: 100px;
			height: 100px;
		}
		#thumbnail-file{
			height: 100%;
			width: 100%;
		}
		#btn-remove-file{
			margin-top: 10px;
		}
        .dropdown-menu-a{
            width: 78%;
            margin-left: 3% !important;
            margin-top: 5px !important;
            text-align: left;
        }
	</style>

