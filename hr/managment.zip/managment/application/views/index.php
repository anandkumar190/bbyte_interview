<!doctype html>
<html>
	<head>
		<title>Managment | <?php echo $title; ?></title>
		<?php include 'layout/link.php' ?>
	</head>
	<body class="login-page">
	<!--Page Container Start Here-->
		<?php include $page . '.php' ?>
	<!--Page Container End Here-->
	</body>
	<?php include 'layout/script.php' ?>
</html>
